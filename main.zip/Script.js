document.addEventListener('DOMContentLoaded', () => {
    console.log('AWS Cloud Information page loaded');
});
